import EditorCmponent from "./component/EditorCmponent";
import FileTree from "./component/FileTree";
import { Box, Grid ,Button} from '@chakra-ui/react';
import React, { useState } from 'react';
import data from "./component/data";
import Navbar from "./component/Navbar";
import Comment from "./component/Comment";
import MiniOption from "./component/MiniOption";

  const App = () => {

    const [currentFile, setCurrentFile] = useState(null);
    const [files, setFiles] = useState(data);

    const handleFileSelect = (file) => {
      setCurrentFile(file);
    };

    const handleContentChange = (newContent) => {
      setCurrentFile((prevFile) => ({
        ...prevFile,
        content: newContent,
      }));
    };
    const saveFile = () => {
      const updateFiles = (items) => {
        return items.map(item => {
          if (item.type === 'folder') {
            return { ...item, children: updateFiles(item.children) };
          } else if (item.name === currentFile.name) {
            return { ...item, content: currentFile.content };
          } else {  
            return item;
          }
        });
      };
      setFiles(updateFiles(files));
    };

    return (
      <Box width="100vw" height="100vh">
        <Grid templateColumns="3fr 7fr" height="100%">
          <Box borderRight="1px solid #ddd">
              <Box> </Box>
            <Grid templateColumns="1fr 9fr" height="100%">
              <Navbar/>
              <Grid templateRows="5% 95%">
                <MiniOption></MiniOption>
                <FileTree data={data} onFileSelect={handleFileSelect} />
              </Grid>
            </Grid>
          </Box>
            <Box>
              <Grid templateRowns="3fr 7fr" height="100%">
              <Box>
                <EditorCmponent file={currentFile} onContentChange={handleContentChange} />
                {currentFile && 
                <Button
                  margin= "5px"
                  colorScheme="blue"
                  size="md"
                  variant="solid"
                  w="50px"
                  color="white"
                  backgroundColor="black" 
                  borderRadius = "5px"
                  border="0px"
                  onClick={saveFile}>Save
                </Button>}
              </Box>
              <Box borderRight="1px solid #ddd" p={0} >
                <Comment/>
              </Box> 
            </Grid>
            </Box>
        </Grid>
      </Box>
    )
  }

  export default App