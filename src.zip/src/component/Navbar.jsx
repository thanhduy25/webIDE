import React from 'react';
import { Box, VStack, IconButton, Tooltip } from '@chakra-ui/react';
import { FaFileUpload ,FaFile, FaSearch, FaGitAlt } from 'react-icons/fa';


const Navbar = ({ onSelectFile, onSearch, onCommit, onUpload }) => {
  return (
    <Box  bg="#dddddd" color="black" width="30px" height="100vh" display="flex" flexDirection="column" alignItems="center" py={4}>
      <VStack spacing={10}>
        <Tooltip placement="right">
          <IconButton
            icon={<FaFile style={{fontSize:'20px' }} />}
            onClick={onSelectFile}
            variant="ghost"
            colorScheme="whiteAlpha"
            style={{ backgroundColor: 'transparent' }}
            border='0px'
            _hover={{ color: "#1a5292", stroke: "blue" }}>
          </IconButton>
        </Tooltip>
        <Tooltip placement="right">
          <IconButton
            icon={<FaSearch style={{fontSize:'20px'  }} />}
            onClick={onSearch}
            variant="ghost"
            colorScheme="whiteAlpha"
            style={{ backgroundColor: 'transparent' }}
            border='0px'
            _hover={{ color: "#1a5292", stroke: "blue" }}
          />
        </Tooltip>
        <Tooltip placement="right">
          <IconButton
            icon={<FaGitAlt style={{fontSize:'20px'  }} />}
            onClick={onCommit}
            variant="ghost"
            colorScheme="whiteAlpha"
            style={{ backgroundColor: 'transparent' }}
            border='0px'
            _hover={{ color: "#1a5292", stroke: "blue" }}
          />
        </Tooltip>
        <Tooltip placement="right">
          <IconButton
            icon={<FaFileUpload style={{fontSize:'20px'  }} />}
            onClick={onUpload}
            variant="ghost"
            colorScheme="whiteAlpha"
            style={{ backgroundColor: 'transparent' }}
            border='0px'
            _hover={{ color: "#1a5292", stroke: "blue" }}
          />
        </Tooltip>
      </VStack>
    </Box>
  );
};

export default Navbar;



