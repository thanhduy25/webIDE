import { Box } from '@chakra-ui/react';
import Editor from '@monaco-editor/react';

const EditorCmponent = ({ file, onContentChange }) => {
    
    if (!file) {
        return <div>Wellcome !</div>;
      }
      const handleChange = (value) => {
        onContentChange(value);
      };
    
  return (
    <Box>
        <Editor 
        theme = "vs-light"
        height="75vh" 
        defaultLanguage="javascript"
        value={file.content}
        onChange={handleChange} 
        /> 
    </Box> 
  )
}

export default EditorCmponent  