
import React, { useState } from 'react';
import { Box, Button, Textarea, Stack } from '@chakra-ui/react';

const Comment = () => {
  const [fileComment, setFileComment] = useState('');

  const handleCommit = () => {
    if (fileComment.trim() !== '') {
      console.log('Comment:', fileComment);
      setFileComment('');
    } else {
      alert('');
    }
  };

  return (
    <Box bg="#dddddd" p={4} borderWidth="1px" borderRadius="lg">
    <Stack spacing={50}>
      <Textarea
        backgroundColor="#eeeeee"
        value={fileComment}
        onChange={(e) => setFileComment(e.target.value)}
        placeholder="Enter comment..."
        resize="vertical"
        h="40px"
        w='200px'
        size="md"
        focusBorderColor="blue.500"
        borderRadius="5px"
        border="0px"  
        borderColor="gray.200"
        _hover={{ borderColor: 'gray.300' }}

      />
      <Button
        onClick={handleCommit}
        colorScheme="blue"
        size="md"
        variant="solid"
        w="100px"
        color="white"
        backgroundColor="black"
        borderRadius = "5px"
        border="0px"
      >
        Comment
      </Button>
    </Stack>
  </Box>
  );
};

export default Comment;